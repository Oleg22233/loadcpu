from rest_framework.response import Response
from rest_framework.views import APIView
from .models import LoadCpu
from .serializers import ArticleSerializer
class ArticleView(APIView):
    def get(self, request):
        articles = LoadCpu.objects.all()
        # the many param informs the serializer that it will be serializing more than a single article.
        serializer = ArticleSerializer(articles, many=True)
        return Response({"articles": serializer.data})
        
    def post(self, request):
        loads =  request.data.get("loads")
        serializer = ArticleSerializer(data=loads)
        if serializer.is_valid(raise_exception=True):
            article_saved = serializer.save()
        return Response({"success": "Article '{}' created successfully".format(article_saved.load)})
        
