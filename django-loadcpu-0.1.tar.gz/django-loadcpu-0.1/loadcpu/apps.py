from django.apps import AppConfig


class LoadcpuConfig(AppConfig):
    name = 'loadcpu'
