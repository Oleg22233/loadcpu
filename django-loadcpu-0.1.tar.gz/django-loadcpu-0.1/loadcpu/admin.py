from django.contrib import admin

# Register your models here.

from .models import LoadCpu

admin.site.register(LoadCpu)
