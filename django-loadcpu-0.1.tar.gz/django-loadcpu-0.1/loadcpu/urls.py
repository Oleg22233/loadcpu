from django.urls import path
from django.conf import settings
from . import views
from django.conf.urls import include, url
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from .views2 import ArticleView

app_name = 'loadcpu'

urlpatterns = [
    # post views
    path('', views.post_load, name='post_load'),
    path('loadcpu/', ArticleView.as_view()),

]




if settings.DEBUG:
    urlpatterns += staticfiles_urlpatterns()
    #urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    #urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    
