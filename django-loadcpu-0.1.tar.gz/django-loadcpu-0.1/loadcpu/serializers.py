from rest_framework import serializers
from .models import  LoadCpu

class ArticleSerializer(serializers.Serializer):
    load = serializers.CharField(max_length=120)
    #description = serializers.CharField()
    #body = serializers.CharField()
    
    def create (self, validated_data):
        return LoadCpu.objects.create(**validated_data)