from django.db import models
from django.db.models import Avg, Max, Min, Sum

# Create your models here.


class LoadCpu(models.Model):
  created = models.DateTimeField(auto_now_add=True)
  load = models.CharField(max_length=120)
  
  @property
  def avgs(self):
      return LoadCpu.objects.all().aggregate(Avg('load'))["load__avg"]
      #yy= LoadCpu.objects.all().order_by('load')[:100].aggregate(Max('load'))["load__max"]
      #yy = LoadCpu.objects.aggregate(Avg('load'))
      return yy
  
  @property
  def avgstop(self):
      yy= LoadCpu.objects.all().order_by('load')[:100].aggregate(Avg('load'))["load__avg"]
      #yy = LoadCpu.objects.aggregate(Avg('load'))
      return yy
  
  @property
  def maxrowtop(self):
      yy= LoadCpu.objects.all().order_by('load')[:100].aggregate(Max('load'))["load__max"]
      #yy = LoadCpu.objects.aggregate(Avg('load'))
      return yy
  @property
  def maxrow(self):
      yy= LoadCpu.objects.all().aggregate(Max('load'))["load__max"]
      #yy = LoadCpu.objects.aggregate(Avg('load'))
      return yy
  
  @property
  def minrowtop(self):
      yy= LoadCpu.objects.all().order_by('load')[:100].aggregate(Min('load'))["load__min"]
      #yy = LoadCpu.objects.aggregate(Avg('load'))
      return yy
  @property
  def minrow(self):
      yy= LoadCpu.objects.all().aggregate(Min('load'))["load__min"]
      #yy = LoadCpu.objects.aggregate(Avg('load'))
      return yy
  
  
  

  
  
#  class Meta: 
#        ordering = ('-created',)
   
  def __str__(self): 
      return self.load
  
 
  

