from rest_framework.response import Response
from rest_framework.views import APIView
from .models import LoadCpu
from .serializers import ArticleSerializer
from django.shortcuts import render, get_object_or_404 
from .models import LoadCpu
from django.db.models.aggregates import Avg

# Create your views here.

class ArticleView(APIView):
    def get(self, request):
        articles = LoadCpu.objects.all()
        # the many param informs the serializer that it will be serializing more than a single article.
        serializer = ArticleSerializer(articles, many=True)
        return Response({"articles": serializer.data})


headers = {'created':'asc',
           'load':'asc',}


def post_load(request):
    
    #avgs =  LoadCpu.average_rating
    avgs = LoadCpu.objects.annotate(avg=Avg('load'))

    sort = request.GET.get('sort')
    if sort is not None:
        if headers[sort] == "des":
            loads = LoadCpu.objects.all().order_by(sort).reverse()[:100]
            headers[sort] = "asc"
        else:
            loads = LoadCpu.objects.all().order_by(sort)[:100]
            headers[sort] = "des"
  
    else:
  
        loads = LoadCpu.objects.all()[:100]
    return render(request,
                  'loadcpu/load.html',
                  {'loads': loads}
                  )
    # return render_to_response("loadcpu/load.html",{'loads':loads})




